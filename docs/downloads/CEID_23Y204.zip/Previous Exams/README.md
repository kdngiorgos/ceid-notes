# Προηγούμενα θέματα — Πιθανότητες και Αρχές Στατιστικής

<!-- BEGIN:sessions -->
| Συνεδρία | Ετικέτα | Μορφή | Μεταγραφή | Λύσεις | Πηγές |
|---|---|---|---|---|---|
| [2018-02](2018-02.md) | Φεβρουάριος 2018 | open | verbatim | [ai-unverified](2018-02.md) | 1 |
| [2020-06](2020-06.md) | Ιούνιος 2020 | open | verbatim | [community](2020-06.md) | 1 |
| [2020-11](2020-11.md) | Νοέμβριος 2020 (online εξέταση, 7 ασκήσεις) | mixed | verbatim | [ai-unverified](2020-11.md) | 7 |
| [2020-12](2020-12.md) | Δεκέμβριος 2020 (online εξέταση, 7 ασκήσεις) | multiple-choice | verbatim | [community](2020-12.md) | 14 |
| [2020](2020.md) | 2020 (απόσπασμα, μήνας άγνωστος) | open | partial | [ai-unverified](2020.md) | 1 |
| [2021-02](2021-02.md) | Φεβρουάριος 2021 (online εξέταση, παραλλαγές) | multiple-choice | verbatim | [ai-unverified](2021-02.md) | 26 |
| [2021-09](2021-09.md) | Σεπτέμβριος 2021 (αποσπάσματα) | open | partial | [ai-unverified](2021-09.md) | 2 |
| [2022-02](2022-02.md) | Φεβρουάριος 2022 (απόσπασμα) | multiple-choice | partial | [ai-unverified](2022-02.md) | 1 |
| [2023-01](2023-01.md) | Ιανουάριος 2023 (απόσπασμα) | multiple-choice | partial | [ai-unverified](2023-01.md) | 1 |
| [2023-02](2023-02.md) | Φεβρουάριος 2023 | open | verbatim | [ai-unverified](2023-02.md) | 4 |
| [2023-09](2023-09.md) | Σεπτέμβριος 2023 | open | verbatim | [ai-unverified](2023-09.md) | 4 |
| [2023-12-a](2023-12-a.md) | Δεκέμβριος 2023 — Εξέταση Προόδου — Ομάδα Α | open | verbatim | [ai-unverified](2023-12-a.md) | 1 |
| [2023-12-b](2023-12-b.md) | Δεκέμβριος 2023 — Εξέταση Προόδου — Ομάδα Β | open | verbatim | [ai-unverified](2023-12-b.md) | 2 |
| [2024-06](2024-06.md) | Ιούνιος 2024 | open | verbatim | [ai-unverified](2024-06.md) | 4 |
| [2024-09](2024-09.md) | Σεπτέμβριος 2024 | open | partial | [ai-unverified](2024-09.md) | 2 |
| [2024-12-a](2024-12-a.md) | Δεκέμβριος 2024 — Εξέταση Προόδου — Ομάδα Α | open | verbatim | [ai-unverified](2024-12-a.md) | 1 |
| [2024-12-b](2024-12-b.md) | Δεκέμβριος 2024 — Εξέταση Προόδου — Ομάδα Β | open | verbatim | [ai-unverified](2024-12-b.md) | 1 |
| [2024-12-c](2024-12-c.md) | Δεκέμβριος 2024 — Ομάδα Β (δεύτερο δελτίο) | open | verbatim | [ai-unverified](2024-12-c.md) | 1 |
| [2025-02](2025-02.md) | Τελική εξέταση χειμερινού εξαμήνου 2024-2025 | open | verbatim | [ai-unverified](2025-02.md) | 1 |
| [2026-02](2026-02.md) | Φεβρουάριος 2026 (σελίδα 5) | open | partial | [ai-unverified](2026-02.md) | 1 |
| [2026-09](2026-09.md) | Σεπτέμβριος 2026 | open | verbatim | [ai-unverified](2026-09.md) | 1 |

Σύνολο: 21 συνεδρίες.

Μεταγραφή: `verbatim` = πιστή αντιγραφή του πρωτοτύπου · `partial` = μερική · `recalled` = ανασύσταση από μνήμης φοιτητών (Discord).  
Λύσεις: `none` = χωρίς λύσεις · `official` = επίσημες · `community` = από φοιτητές · `ai-unverified` = από AI, **μη επαληθευμένες** · `verified` = ελεγμένες.

Ανακλήσεις θεμάτων από το Discord: [discord_recalls.md](discord_recalls.md)
<!-- END:sessions -->
