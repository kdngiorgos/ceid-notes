# Προηγούμενα θέματα — Προγραμματισμός και Συστήματα στον Παγκόσμιο Ιστό

<!-- BEGIN:sessions -->
| Συνεδρία | Ετικέτα | Μορφή | Μεταγραφή | Λύσεις | Πηγές |
|---|---|---|---|---|---|
| [2025-06-b](2025-06-b.md) | Ιούνιος 2025 — Ομάδα Β | multiple-choice | partial | [ai-unverified](2025-06-b.md) | 1 |
| [2025-02-b](2025-02-b.md) | Φεβρουάριος 2025 — Ομάδα Β | multiple-choice | partial | [ai-unverified](2025-02-b.md) | 7 |
| [2024-06](2024-06.md) | Ιούνιος 2024 | multiple-choice | partial | [community](2024-06.md) | 4 |
| [2023-09-b](2023-09-b.md) | Σεπτέμβριος 2023 — Παραλλαγή Β | multiple-choice | verbatim | [ai-unverified](2023-09-b.md) | 2 |
| [2023-09-a](2023-09-a.md) | Σεπτέμβριος 2023 — Ομάδα Α | multiple-choice | verbatim | [ai-unverified](2023-09-a.md) | 2 |
| [2023-02](2023-02.md) | Φεβρουάριος 2023 | multiple-choice | partial | [community](2023-02.md) | 5 |
| [2022-06](2022-06.md) | Ιούνιος 2022 | multiple-choice | partial | [ai-unverified](2022-06.md) | 1 |
| [2022-01-b](2022-01-b.md) | Ιανουάριος 2022 (β) | multiple-choice | partial | [ai-unverified](2022-01-b.md) | 2 |
| [2022-01-a](2022-01-a.md) | Ιανουάριος 2022 (α) | multiple-choice | partial | [ai-unverified](2022-01-a.md) | 2 |
| [2021-06](2021-06.md) | Ιούνιος 2021 | multiple-choice | partial | [community](2021-06.md) | 3 |
| [2021-02](2021-02.md) | Φεβρουάριος 2021 | multiple-choice | partial | [ai-unverified](2021-02.md) | 23 |
| [2021-01](2021-01.md) | Ιανουάριος 2021 | multiple-choice | partial | [ai-unverified](2021-01.md) | 4 |
| [2020-09](2020-09.md) | Σεπτέμβριος 2020 | multiple-choice | partial | [community](2020-09.md) | 7 |

Σύνολο: 13 συνεδρίες.

Μεταγραφή: `verbatim` = πιστή αντιγραφή του πρωτοτύπου · `partial` = μερική · `recalled` = ανασύσταση από μνήμης φοιτητών (Discord).  
Λύσεις: `none` = χωρίς λύσεις · `official` = επίσημες · `community` = από φοιτητές · `ai-unverified` = από AI, **μη επαληθευμένες** · `verified` = ελεγμένες.

Ανακλήσεις θεμάτων από το Discord: [discord_recalls.md](discord_recalls.md)
<!-- END:sessions -->
